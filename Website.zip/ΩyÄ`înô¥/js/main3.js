
  const orderS = document.querySelectorAll('select')[0];
  const orderSS = document.querySelectorAll('select')[1];
  const orderSSS = document.querySelectorAll('select')[2];
  const form = document.getElementById("form");
  const namev = document.querySelector('input');
  // 菜單
  var menu = ["----板燒漢堡----","----活力蛋餅----","----活力蛋餅(酥皮)----","----日式穀堡----",
              "----厚片----","----法國吐司----","----板燒吐司----","----起酥堡----","----疏食捲餅----",
              "----法式麵包----","----田園蔬果----","----中式茶食----","----多殼豆漿----","----古早味豆漿----",
              "----純味茶----","----鮮奶+茶----","----義式咖啡----","----奶茶----","----美式狂想套餐----"];
  //項目
  var item1 = [ "玉米蛋:", "肉鬆蛋:", "豬肉蛋:", "烤肉蛋:", "香雞蛋:", "牛肉蛋:", "總匯蛋:", "日式雞排蛋:", "日式豬排蛋:","日式花枝排蛋:","日式蝦排蛋:","雞腿蛋(辣/原):"];
  var item2 = ["原味蛋餅:", "肉鬆蛋餅:", "玉米蛋餅:", "起司蛋餅:", "萵苣蛋餅:","洋蔥蛋餅:","火腿蛋餅:","培根蛋餅:","熱狗蛋餅:","鮪魚蛋餅:","烤肉蛋餅:"];
  var item3 = ["原味蛋餅:", "肉鬆蛋餅:", "玉米蛋餅:", "起司蛋餅:", "萵苣蛋餅:","洋蔥蛋餅:","火腿蛋餅:","培根蛋餅:","熱狗蛋餅:","鮪魚蛋餅:","烤肉蛋餅:"];
  var item4 = ["日式疏食沙拉","日式咖哩","冰洲魚排","大洋鮮魚","孜然醬雞排","孜然醬豬排"];
  var item5 = ["----果醬系列----","草莓","藍莓","花生","奶油","奶酥","巧克力","----其他----","起司奶油","鮪魚洋蔥","燻雞起司"];
  var item6 = ["----果醬系列----","草莓","藍莓","花生","奶油","奶酥","巧克力","----其他----","日式培根","深海鮪魚","黃金烤肉"];
  var item7 = ["煎蛋吐司","玉米蛋","肉鬆蛋","起士蛋","火腿蛋","培根蛋","鮪魚蛋","烤肉蛋","香雞蛋","總匯蛋"];
  var item8 = ["草莓起酥","洋洋疏食","苜蓿芽玉米","番茄萵苣","萵苣烤肉"];
  var item9 = ["香雞番茄","黃金烤肉","日式雞排","海味花枝","鮮味蝦排","美式雞腿(辣/原)"];
  var item10 = ["火腿起司","番茄豬肉","苜蓿芽起司","陽光香雞","萵苣烤肉","日式燻雞"];
  var item11 = ["馬鈴薯吐司","南光吐司","全麥萵苣鮪魚","全麥苜蓿芽火腿","全麥蔬菜沙拉","田園蔬菜捲","田園什錦蔬菜盒"];
  var item12 = ["荷包蛋","熱狗(4條)","玉米濃湯","薯餅(四片)","鍋貼","炒麵","雞塊","蘿蔔糕","鐵板麵","脆薯","美式湯麵","烤肉炒麵"];
  var item13 = ["多殼豆漿M","多殼豆漿L","多殼紅茶M","多殼紅茶L","多殼紅茶豆漿M","多殼紅茶豆漿L","多殼奶茶M","多殼奶茶L",
                "多殼綠奶M","多殼綠奶L","多殼薏仁漿M","多殼薏仁漿L"];
  var item14 = ["研磨豆漿M","研磨豆漿L","紅茶豆漿M","紅茶豆漿L","胚芽豆漿M","胚芽豆漿L","薏仁豆漿M","薏仁豆漿L",
                "抹茶豆漿M","抹茶豆漿L","養生薏仁漿M","養生薏仁漿L"];   
  var item15 = ["阿薩姆紅茶M","阿薩姆紅茶L","茉香綠茶M","茉香綠茶L","高山清茶M","高山清茶L","東方美人M","東方美人L",
                "黃金烏龍M","黃金烏龍L","阿里山M","阿里山L","玄米玉露M","玄米玉露L","四季綠茶M","四季綠茶L"];
  var item16 = ["東方拿鐵M","烏龍拿鐵M","阿里山拿鐵M","四季拿鐵M","玄米拿鐵M"];
  var item17 = ["豆奶拿鐵M","特調咖啡M","義式咖啡M","拿鐵咖啡M","卡布奇諾M"];
  var item18 = ["阿薩姆奶茶M","阿薩姆奶茶L","莫香奶綠M","莫香奶綠L","高山青奶M","高山青奶L",
                "胚芽奶茶M","胚芽奶茶L","茶珠青奶M","茶珠青奶L","茶珠綠奶M","茶珠綠奶L"];         
  var item19 = ["1-花醬牛肉培根起司蛋堡","2-蜂蜜芥末德式勳腸捲餅","3-日式白醬酥炸鱈魚蛋堡","4-雙層澳洲牛肉起司蛋堡",
                "5-雙層豬肉起司蛋堡","6-清爽薯泥培根起司蛋堡","7-泰式風味旗魚起司蛋堡","8-日式咖哩豬排起司蛋堡",
                "9-香濃雞排起司法國吐司","10-美味豬排起司蛋總匯吐司","11-消暑千島醬薯泥雞排起司吐司","12-甜辣泰式雞排起司蛋蛋捲餅"];
  // 價錢
  var price1 = ["30元", "30元", "35元", "40元", "40元", "40元", "45元", "45元", "45元", "45元", "45元", "50元"];
  var price2 = ["25元","30元","30元","30元","30元","30元","35元","35元","35元","35元","40元"]
  var price3 = ["30元","35元","35元","35元","35元","35元","40元","40元","40元","40元","45元"];
  var price4 = ["35元","35元","45元","45元","45元","45元"];
  var price5 = ["","25元","25元","25元","25元","25元","25元","","30元","35元","45元"];
  var price6 = ["","25元","25元","25元","25元","25元","25元","","35元","35元","40元"];
  var price7 = ["25元","30元","30元","30元","35元","35元","35元","40元","40元","45元"];
  var price8 = ["30元","35元","35元","35元","45元"];
  var price9 = ["40元","45元","45元","45元","45元","50元"];
  var price10 = ["40元","40元","40元","40元","50元","50元"];
  var price11 = ["30元","30元","35元","35元","35元","35元","40元"];
  var price12 = ["10元","20元","20元","30元","30元","30元","30元","30元","35元","30元",
                 "35元","45元"];
  var price13 = ["25元","35元","25元","35元","25元","35元","30元","40元","30元","40元","35元","45元"];
  var price14 = ["15元","20元","15元","20元","20元","25元","25元","30元","25元","30元","25元","30元"];
  var price15 = ["15元","20元","15元","20元","15元","20元","30元","30元","30元","30元","30元","30元",
                 "30元","30元","30元","30元"];
  var price16 = ["45元","45元","45元","45元","45元"];
  var price17 = ["35元","35元","35元","50元","50元"];
  var price18 = ["20元","25元","20元","25元","20元","25元","25元","30元","30元","40元","30元","40元"];
  var price19 = ["84元","84元","84元","84元","84元","84元","84元","84元","84元","84元",
                 "84元","84元"];
  // 網站監聽載入時呼叫建立菜單Function
  window.addEventListener('load', limitTime);
  window.addEventListener('load', crateMenulist);
  // 限制時間
  function limitTime() {
    var currentTime = new Date();
    var setTime = new Date(currentTime.getFullYear(),currentTime.getMonth(),
    currentTime.getDate(),10,31,0 );
    var urll = "../img/1668366.jpg";          
    if(currentTime.getTime() > setTime.getTime()){
      document.body.innerHTML="";
      alert("目前不在使用時段(截止時間為10:30)，下次請早~\n"+currentTime);
      document.body.setAttribute("background", urll);


    };
  }
　// 建立菜單

  //系列列表
  function crateMenulist() {
    for (var i = 0; i < menu.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(menu[i]));
      orderS.appendChild(op);
      //op.setAttribute("text",menu[i]+price[i])
      op.innerHtml = menu[i];
    }
  }
  //板燒漢堡
  function crateMenulist1() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item1.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item1[i]+price1[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price1[i]);
      op.innerHtml = item1[i]+price1[i];
      op.setAttribute("id", "opb1" + i);
    }
  }
  //蛋餅
  function crateMenulist2() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item2.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item2[i]+price2[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price2[i]);
      op.innerHtml = item2[i]+price2[i];
      op.setAttribute("id", "opb2" + i);
    }
  }
  //蛋餅(酥皮)
  function crateMenulist3() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item3.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item3[i]+price3[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price3[i]);
      op.innerHtml = item3[i]+price3[i];
      op.setAttribute("id", "opb3" + i);
    }
  }
  //日式穀堡
  function crateMenulist4() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item4.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item4[i]+price4[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price4[i]);
      op.innerHtml = item4[i]+price4[i];
      op.setAttribute("id", "opb4" + i);
    }
  }
  //厚片
  function crateMenulist5() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item5.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item5[i]+price5[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price5[i]);
      op.innerHtml = item5[i]+price5[i];
      op.setAttribute("id", "opb5" + i);
    }
    
  }

  //法國土司
  function crateMenulist6() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item6.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item6[i]+price6[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price6[i]);
      op.innerHtml = item6[i]+price6[i];
      op.setAttribute("id", "opb6" + i);
    }
  }
  
  //板燒土司
  function crateMenulist7() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item7.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item7[i]+price7[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price7[i]);
      op.innerHtml = item7[i]+price7[i];
      op.setAttribute("id", "opb7" + i);
    }
  }

  //起酥堡
  function crateMenulist8() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item8.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item8[i]+price8[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price8[i]);
      op.innerHtml = item8[i]+price8[i];
      op.setAttribute("id", "opb8" + i);
    }
  }

  //疏食捲餅
  function crateMenulist9() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item9.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item9[i]+price9[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price9[i]);
      op.innerHtml = item9[i]+price9[i];
      op.setAttribute("id", "opb9" + i);
    }
  }

  //法式麵包
  function crateMenulist10() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item10.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item10[i]+price10[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price10[i]);
      op.innerHtml = item10[i]+price10[i];
      op.setAttribute("id", "opb10" + i);
    }
  }

  //田園疏果
  function crateMenulist11() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item11.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item11[i]+price11[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price11[i]);
      op.innerHtml = item11[i]+price11[i];
      op.setAttribute("id", "opb11" + i);
    }
  }

  //中式茶食
  function crateMenulist12() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item12.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item12[i]+price12[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price12[i]);
      op.innerHtml = item12[i]+price12[i];
      op.setAttribute("id", "opb12" + i);
    }
  }

  //多穀豆漿
  function crateMenulist13() {
    for (var i = 0; i < item13.length; i++) {
      var op = document.createElement("option");     
      op.appendChild(document.createTextNode(item13[i]+price13[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price13[i]);
      op.innerHtml = item13[i]+price13[i];
      op.setAttribute("id", "opb13" + i);
      document.getElementById("number3").removeAttribute("hidden");
    }
  }

  //古早味豆漿
  function crateMenulist14() {
    for (var i = 0; i < item14.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item14[i]+price14[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price14[i]);
      op.innerHtml = item14[i]+price14[i];
      op.setAttribute("id", "opb14" + i);
      document.getElementById("number3").removeAttribute("hidden");
    }
  }

  //純味茶
  function crateMenulist15() {
    for (var i = 0; i < item15.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item15[i]+price15[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price15[i]);
      op.innerHtml = item15[i]+price15[i];
      op.setAttribute("id", "opb15" + i);
      document.getElementById("number3").removeAttribute("hidden");
    }
  }

  //鮮奶+茶
  function crateMenulist16() {
    for (var i = 0; i < item16.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item16[i]+price16[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price16[i]);
      op.innerHtml = item16[i]+price16[i];
      op.setAttribute("id", "opb16" + i);
      document.getElementById("number3").removeAttribute("hidden");
    }
  }

  //義式咖啡
  function crateMenulist17() {
    for (var i = 0; i < item17.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item17[i]+price17[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price17[i]);
      op.innerHtml = item17[i]+price17[i];
      op.setAttribute("id", "opb17" + i);
      document.getElementById("number3").removeAttribute("hidden");
    }
  }

  //奶茶
  function crateMenulist18() {
    for (var i = 0; i < item18.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item18[i]+price18[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price18[i]);
      op.innerHtml = item18[i]+price18[i];
      op.setAttribute("id", "opb18" + i);
      document.getElementById("number3").removeAttribute("hidden");
    }
  }

  //美式狂想套餐
  function crateMenulist19() {
    document.getElementById("number3").setAttribute("hidden","");
    for (var i = 0; i < item19.length; i++) {
      var op = document.createElement("option");
      op.appendChild(document.createTextNode(item19[i]+price19[i]));
      orderSS.appendChild(op);
      op.setAttribute("value",price19[i]);
      op.innerHtml = item19[i]+price19[i];
      op.setAttribute("id", "opb19" + i);
    }
  }

  //監聽選擇系列內容並建立各系列菜單
  orderS.addEventListener('change', test);
  function test() {
    orderSS.options.length = 0;
    var sesV = "";
    $('#number').each(function(index) {
       var ses = document.getElementById("number");
       if($(this).val() !== ''){
         sesV = String(ses.options[ses.selectedIndex].text);
         crateSeriselist(sesV);
       }
   })
  }
  //判斷選擇系列
  function crateSeriselist(sesV) {
       switch(sesV){
        case ("----板燒漢堡----"):         
         crateMenulist1();
         break
        case ("----活力蛋餅----"):
         crateMenulist2();
         break
        case ("----活力蛋餅(酥皮)----"):
         crateMenulist3();
         break
        case ("----日式穀堡----"):
         crateMenulist4();
         break
        case ("----厚片----"):
         crateMenulist5();
         break
        case ("----法國吐司----"):
         crateMenulist6();
         break
        case ("----板燒吐司----"):
         crateMenulist7();
         break
        case ("----起酥堡----"):
         crateMenulist8();
         break 
        case ("----疏食捲餅----"):
         crateMenulist9();
         break
        case ("----法式麵包----"):
         crateMenulist10();
         break 
        case ("----田園蔬果----"):
         crateMenulist11();
         break
        case ("----中式茶食----"):
         crateMenulist12();
         break
        case ("----多殼豆漿----"):
         crateMenulist13();
         break
        case ("----古早味豆漿----"):
         crateMenulist14();
         break
        case ("----純味茶----"):
         crateMenulist15();
         break
        case ("----鮮奶+茶----"):
         crateMenulist16();
         break
        case ("----義式咖啡----"):
         crateMenulist17();
         break
        case ("----奶茶----"):
         crateMenulist18();
         break
        case ("----美式狂想套餐----"):
         crateMenulist19();
         break         
       }
  }
  //按下送出後處理
 $(function(){
        // 監聽 送出訂單 按鈕點擊
        $('#sendOrder').click(function(e){
        var status = true;
        // 姓名
        var name = $('#name').val();
        // 數量
        //var total = $('#number2').val();
        // 訂單
        var order = '';
        // 價錢
        var price = "";
        
        // 處理價錢 跟 訂單 資料
        $('#number2').each(function(index) {
          var ses = document.getElementById("number");
          var ses2 = document.getElementById("number2");
          var ses3 = document.getElementById("number3");
          var sesV = String(ses.options[ses.selectedIndex].text);
          if($(this).val() !== ''){
            order = sesV + String(ses2.options[ses2.selectedIndex].text)+ "-" + ses3.value + "-" + '1份 ';
            price += parseInt($(this).val()) + 5;
          }
        });
        //order = order.substring(0, order.length - 1);
        /*$('#number2').each(function(index) {
          if($(this).val() !== ''){
            var totalPrice = total * price;
            price2 += price + "x" + total + "=" + totalPrice + '元';
          }
        });*/
        // 擋住不填資料
        if(name == ''){
          $('#name').css('border','1px solid #ff0000');
          status = false;
        }
        if(order == ''  ){
        alert('請選擇訂購品項喔');
        status = false;
        }
        //if(total == ''  ){
        //alert('請選擇數量喔');
        //status = false;
        //}

        if(status){
          // 日期資料
          var currentdate = new Date();
          var filltime = currentdate.getFullYear() + "/"
                + (currentdate.getMonth() + 1) + "/"
                + currentdate.getDate() + "  "
                + currentdate.getHours() + ":"
                + currentdate.getMinutes() + ":"
                + currentdate.getSeconds();
          // 打包 
          var data = {
            'name' : name,
            //'phone':phone,
            'time': filltime,
            'order': order,
            'price': price,
          }
          // 呼叫 send ajax function
          send(data);
        }
      });
    });



    function send(data){
      $.ajax({
        // get type
        type: "get",
        // api url
        url: "https://script.google.com/macros/s/AKfycbzv24Kx8LYwpHbHjHpITM05p3fnQiCKF50HX90H0WxvROueX6mBPHy3fpG5F48cbuV2uA/exec",
        // 資料帶入
        data: data,
        // 資料格式JSON 
        dataType: "JSON",
        success: function (response) {
          console.log(response);
          alert('點餐完成！！');
        // 清空欄位 
          namev.value = "";
          orderS.value ="";
          orderSS.value ="";
          orderSSS.value ="";
        }
      });
      

    }
//----------------------------------------------------------------------
  